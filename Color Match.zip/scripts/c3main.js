import "./c3runtime.js";
import "./objRefTable.js";
